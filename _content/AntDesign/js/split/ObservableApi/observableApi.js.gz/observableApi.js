export { resizeObserver as resize } from './resizeObserver';
